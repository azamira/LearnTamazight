GeoIP2-City-Test.mmdb:
    Copyright: maxmind (github.com/maxmind)

    https://github.com/maxmind/MaxMind-DB/blob/master/test-data/GeoIP2-City-Test.mmdb

    Licence: Creative Commons Attribution-ShareAlike 3.0 Unported License

    http://creativecommons.org/licenses/by-sa/3.0/

    No changes have been made to this file.
