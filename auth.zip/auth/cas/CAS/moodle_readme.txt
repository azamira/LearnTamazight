Description of phpCAS 1.3.7 library import

* downloaded from http://downloads.jasig.org/cas-clients/php/current/
* applied patch https://github.com/apereo/phpCAS/pull/247 for PHP 7.2 compatibility (MDL-60280)
* applied patch https://github.com/apereo/phpCAS/pull/278 for PHP 7.3 compatibility (MDL-63422)
