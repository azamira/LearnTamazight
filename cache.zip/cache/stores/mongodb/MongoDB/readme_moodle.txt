MongoDB PHP
-----------
Download from https://github.com/mongodb/mongo-php-library

Import procedure:

- Copy all the files and folders from the folder mongodb/src in this directory.
- Copy the license file from the project root.
- Update thirdpartylibs.xml with the latest version.

2019/03/14
----------
Last commit on download: aac8e54009196f6544e50baf9b63dcf0eab3bbdf

This version (1.4.2) requires PHP mongodb extension >= 1.5
